<!--#include file="a.js" -->
<!--#include file="b.js" -->
